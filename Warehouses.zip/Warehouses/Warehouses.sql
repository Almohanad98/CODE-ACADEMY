-- 1. Count the Number of Customers
select count(*) as NO_cust from customers;

-- 2. Sum of All Orders' Quantities
select sum(quantity) from order_items;
select order_date, sum (quantity)
from order_items oi 
join orders on (oi.order_id=o.order_id)

group by order_date;



-- 3. Average List Price of Products
select avg(list_price)
from products;

-- 4. Maximum Credit Limit of Customers
SELECT MAX(Credit_Limit) 
FROM Customers;

-- 5. Minimum Quantity in Inventories
SELECT MIN(Quantity) 
FROM Inventories;

-- 6. Group by Example: Total Sales by Status
SELECT Status, SUM(Quantity * unit_price) AS TotalSales
FROM Orders 
join order_items on (order_items.order_id= orders.order_id)
GROUP BY Status;


-- 7. Group by with Having Clause: Products with Total Quantity Greater Than 1000
select Product_name, SUM(Quantity) AS TotalQuantity
from order_items 
JOIN products ON ( order_items.product_id= products.product_id)
group by product_name
HAVING SUM(Quantity) > 1000;



-- 8. Number of Employees Grouped by Job Title
SELECT JOB_TITLE, COUNT(*) AS NumberOfEmployees
FROM EMPLOYEES
GROUP BY JOB_TITLE;

-- 9. Total Number of Warehouses by Country
SELECT C.COUNTRY_NAME, COUNT(W.WAREHOUSE_ID) AS TotalWarehouses
FROM WAREHOUSES W
JOIN LOCATIONS L ON W.LOCATION_ID = L.LOCATION_ID
JOIN COUNTRIES C ON L.COUNTRY_ID = C.COUNTRY_ID
GROUP BY C.COUNTRY_NAME;

-- 10. Total Revenue from All Orders
SELECT SUM(QUANTITY * UNIT_PRICE) AS TotalRevenue
FROM ORDER_ITEMS;


-- ---- 
-- 1. List All Orders with Customer Information
-- 2. Find All Products with Their Categories
-- 3. Get Employee Details Along with Their Manager's Name
-- 4. List All Customers and Their Contacts
-- 5. Find Products Available in Specific Warehouses
-- 6. Get the Total Number of Orders by Each Salesman
-- 7. List Locations and the Number of Warehouses in Each City
-- 8. Get All Orders and Their Status with Customer and Salesman DetaSils
-- 9. Find Regions and the Number of Countries in Each Region
-- 10. List Employees Working in a Specific Location
